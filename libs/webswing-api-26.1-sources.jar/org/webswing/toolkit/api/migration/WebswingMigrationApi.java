package org.webswing.toolkit.api.migration;

import java.awt.Component;
import java.awt.Graphics;
import java.util.Map;

import javax.swing.JComponent;
import javax.swing.plaf.ComponentUI;

import org.webswing.toolkit.api.car.WebUI;
import org.webswing.toolkit.api.car.WebUIStateProvider;
import org.webswing.toolkit.api.car.forms.FormsWebUI;
import org.webswing.toolkit.api.migration.forms.FormsMigrationFilter;

public interface WebswingMigrationApi {
	
	/**
	 * Check whether this implementation of Migration API is extended. Extended API comes with implementation of methods that are not available in basic Migration API.
	 * Calling methods implemented only in extended API on basic API results in {@link UnsupportedOperationException}.
	 * 
	 * @return true if this is an extended implementation of Migration API
	 */
	boolean isExtendedApi();
	
	// below methods are part of extended migration api only
	
	/**
	 * Reset internal state of migrated components. Reseting the state will cause the full state of web components to be sent to frontend.
	 */
	void resetWebUIState();
	
	/**
	 * Create instance of ComponentUI class for given component. This should be called from createUI method of ComponentUI implementation.
	 *  
	 * @param c component to create UI class for
	 * @return created instance of ComponentUI class
	 */
	ComponentUI createComponentUI(JComponent c);
	
	/**
	 * Migrate all Swing components that have registered given uiClassId to a custom WebUI implementation of UI class. 
	 * Use this to provide a custom implementation of WebUI.
	 * If you are migrating a built-in LAF UI class, webUIClass parameter must be an implementation of WebUI interface.
	 * If you are migrating a custom UI class, webUIClass parameter must be an implementation of WebUI interface and also must extend ComponentUI to provide UI class implementation.
	 * <br>
	 * Example:
	 * <pre>
	 * migrateComponent(ComponentUIClassId.ButtonUI, CustomButtonUI.class);
	 * </pre>
	 * 
	 * @param uiClassId uiClassId provided by the component that is to be migrated (i.e. JComponent.getUIClassID()) 
	 * @param webUIClass class that extends WebUI interface to replace the default implementation class
	 */
	void migrateComponent(String uiClassId, Class<? extends WebUI> webUIClass);
	
	/**
	 * Migrate all Oracle Forms components that have registered given itemId to a custom FormsWebUI implementation class. 
	 * Use this to provide a custom implementation of WebUI.
	 * If you are migrating a built-in Forms Component class, webUIClass parameter must be an implementation of FormsWebUI interface.
	 * <br>
	 * Example:
	 * <pre>
	 * migrateComponent(FormsComponentUIClassId.ButtonUI, CustomButtonUI.class);
	 * </pre>
	 * 
	 * @param webUIClass class that extends WebUI interface to replace the default implementation class
	 */
	void migrateFormsComponent(String itemId, Class<? extends FormsWebUI> webUIClass);
	
	/**
	 * Request that the given component is painted as a web component.
	 * 
	 * @param g graphics object provided in paint process
	 * @param c component to be painted as a web component (migrated)
	 * @return true if the process of painting web component succeeded
	 */
	boolean paintWeb(Graphics g, JComponent c);
	
	/**
	 * Request that the given component is painted as a web component.
	 * 
	 * @param g graphics object provided in paint process
	 * @param c component to be painted as a web component (migrated)
	 * @return true if the process of painting web component succeeded
	 */
	boolean paintFormsWeb(Graphics g, Component c);
	
	/**
	 * Replace current state (WebUIState) of a migrated component. Provide only properties that should be replaced.
	 * Replacing a state for a property causes that the property state will NOT be propagated to frontend. 
	 * Use this to synchronize the state from frontend. 
	 * 
	 * @param c component to replace the state for
	 * @param props property map to replace
	 */
	void replaceState(JComponent c, Map<String, String> props);
	
	/**
	 * Replace current state (WebUIState) of a migrated component.
	 * Replacing a state for a property causes that the property state will NOT be propagated to frontend. 
	 * Use this to synchronize the state from frontend. 
	 * 
	 * @param c component to replace the state for
	 * @param propName property name to replace
	 * @param propValue property value to replace
	 */
	void replaceState(JComponent c, String propName, String propValue);
	
	/**
	 * Replace current state (WebUIState) of a migrated Forms component. Provide only properties that should be replaced.
	 * Replacing a state for a property causes that the property state will NOT be propagated to frontend. 
	 * Use this to synchronize the state from frontend. 
	 * 
	 * @param c component to replace the state for
	 * @param props property map to replace
	 */
	void replaceFormsState(Component c, Map<String, String> props);
	
	/**
	 * Replace current state (WebUIState) of a migrated Forms component.
	 * Replacing a state for a property causes that the property state will NOT be propagated to frontend. 
	 * Use this to synchronize the state from frontend. 
	 * 
	 * @param c component to replace the state for
	 * @param propName property name to replace
	 * @param propValue property value to replace
	 */
	void replaceFormsState(Component c, String propName, String propValue);

	/**
	 * Register given component as a component that is migrated through overridden JComponent.paintComponent
	 * 
	 * @param c component to be painted as a web component (migrated)
	 * @param webUI provider of state and event handler of the migrated component
	 */
	void registerWebPaint(JComponent c, WebUI webUI);
	
	/**
	 * Unregister given component as a component that is migrated through overridden JComponent.paintComponent
	 * 
	 * @param c component to unregister
	 */
	void unregisterWebPaint(JComponent c);

	/**
	 * Set a migration filter that defines which components should be migrated/migrated fully.
	 * This should be used together with api.migrateComponent method to limit the set of components that are migrated.
	 * 
	 * @param filter the filter implementation
	 */
	void setMigrationFilter(MigrationFilter filter);
	
	/**
	 * Set a migration filter that defines which Forms components should be migrated.
	 * This should be used together with api.migrateFormsComponent method to limit the set of components that are migrated.
	 * 
	 * @param filter the filter implementation
	 */
	void setFormsMigrationFilter(FormsMigrationFilter filter);
	
	/**
	 * Register global event handler that does a custom handling of web component events.
	 * 
	 * @param eventHandler the implementation of event handler
	 */
	void setGlobalEventHandler(GlobalWebUIEventHandler eventHandler);

	/**
	 * Register global state provider that provides custom states for web components.
	 * 
	 * @param stateProvider the implementation of state provider
	 */
	void setGlobalStateProvider(WebUIStateProvider stateProvider);

	/**
	 * Request that the web component counterpart of given migrated component is disposed.
	 * Use this to dispose of a web component that uses '__preventDisposal()' function to prevent disposal when JComponent is hidden in UI.
	 * The web component will be disposed only in case it is not visible in the UI.
	 * @param c component for which the web component should be disposed
	 */
	void disposeMigratedComponent(JComponent c);
	
	/**
	 * Request that the web component counterpart of given migrated component is disposed.
	 * Use this to dispose of a web component that uses '__preventDisposal()' function to prevent disposal when Component is hidden in UI.
	 * The web component will be disposed only in case it is not visible in the UI.
	 * @param c component for which the web component should be disposed
	 */
	void disposeMigratedFormsComponent(Component c);
	
}
