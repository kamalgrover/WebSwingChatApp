package org.webswing.toolkit.api.migration;

import javax.swing.JComponent;

import org.webswing.toolkit.api.car.WebComponentFocusTraversalPolicy;

public class WebswingMigrationUtil {

	/**
	 * Setup focus traversal policy for component that is migrated and contains other components (like arrow buttons in JSpinner)
	 * that were installed with UI class. The migrated UI may be different and this traversal policy prevents the contained components to be focused.
	 * @param c component to setup focus traversal policy
	 */
	public static void setupWebFocusTraversalPolicy(JComponent c) {
		c.setFocusable(true);
		c.setFocusTraversalPolicyProvider(true);
		c.setFocusTraversalPolicy(new WebComponentFocusTraversalPolicy());
	}
	
}
