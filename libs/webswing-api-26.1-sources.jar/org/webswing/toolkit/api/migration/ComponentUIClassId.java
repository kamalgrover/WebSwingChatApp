package org.webswing.toolkit.api.migration;

public interface ComponentUIClassId {
	
	String ButtonUI = "ButtonUI";
	String TextFieldUI = "TextFieldUI";
	String PanelUI = "PanelUI";
	String LabelUI = "LabelUI";
	String ComboBoxUI = "ComboBoxUI";
	String CheckBoxUI = "CheckBoxUI";
	String PasswordFieldUI = "PasswordFieldUI";
	String RadioButtonUI = "RadioButtonUI";
	String ProgressBarUI = "ProgressBarUI";
	String ToggleButtonUI = "ToggleButtonUI";
	String SeparatorUI = "SeparatorUI";
	String PopupMenuSeparatorUI = "PopupMenuSeparatorUI";
	String ToolBarSeparatorUI = "ToolBarSeparatorUI";
	String ToolTipUI = "ToolTipUI";
	String TextAreaUI = "TextAreaUI";
	String SliderUI = "SliderUI";
	String PopupMenuUI = "PopupMenuUI";
	String MenuItemUI = "MenuItemUI";
	String MenuUI = "MenuUI";
	String MenuBarUI = "MenuBarUI";
	String SpinnerUI = "SpinnerUI";
	String FormattedTextFieldUI = "FormattedTextFieldUI";
	String CheckBoxMenuItemUI = "CheckBoxMenuItemUI";
	String RadioButtonMenuItemUI = "RadioButtonMenuItemUI";
	
//	String ToolBarUI = "ToolBarUI";
	
//	String ListUI = "ListUI";
//	String TabbedPaneUI = "TabbedPaneUI";
//	String TableUI = "TableUI";
//	String TableHeaderUI = "TableHeaderUI";
//	String TreeUI = "TreeUI";
	
//	String ColorChooserUI = "ColorChooserUI";
//	String DesktopIconUI = "DesktopIconUI";
//	String DesktopPaneUI = "DesktopPaneUI";
//	String EditorPaneUI = "EditorPaneUI";
//	String FileChooserUI = "FileChooserUI";
//	String InternalFrameUI = "InternalFrameUI";
//	String OptionPaneUI = "OptionPaneUI";
//	String RootPaneUI = "RootPaneUI";
//	String ScrollBarUI = "ScrollBarUI";
//	String ScrollPaneUI = "ScrollPaneUI";
//	String SplitPaneUI = "SplitPaneUI";
//	String TextPaneUI = "TextPaneUI";
//	String ViewportUI = "ViewportUI";
	
	String WebswingHtmlPanelUI = "WebswingHtmlPanelUI";

}
