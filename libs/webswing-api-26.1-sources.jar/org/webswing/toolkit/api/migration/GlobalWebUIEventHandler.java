package org.webswing.toolkit.api.migration;

import javax.swing.JComponent;

import org.webswing.toolkit.api.action.WebActionEvent;

public interface GlobalWebUIEventHandler {

	/**
	 * Handle event triggered from a web component.
	 * 
	 * @param c component for which the event has been triggered
	 * @param webEvent event to handle
	 * @return true if the event has been handled, false if you want the default handler to handle the event
	 */
	public boolean handleWebEvent(JComponent c, WebActionEvent webEvent);
	
}
