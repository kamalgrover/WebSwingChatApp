package org.webswing.toolkit.api.migration;

import javax.swing.JComponent;

public interface MigrationFilter {

	public boolean shouldMigrate(JComponent c, String uiClassId);
	
	public default boolean shouldMigrateFully(JComponent c, String uiClassId) {
		return false;
	}
	
}
