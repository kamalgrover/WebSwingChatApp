package org.webswing.toolkit.api.migration.forms;

import java.awt.Component;

public interface FormsMigrationFilter {

	public boolean shouldMigrate(Component c, String uiClassId);
	
}
