package org.webswing.toolkit.api.migration.forms;

public interface WSItem {
	
	public static final String PROP_MIGRATE = "WS_MIGRATE";

	public String getCustomProperty(String propName);
	
}
