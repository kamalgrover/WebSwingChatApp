package org.webswing.toolkit.api.migration.forms;

public interface FormsComponentItemId {
	
	String Button = "org.webswing.forms.toolkit.item.WSButtonItem";
	String IconicButton = "org.webswing.forms.toolkit.item.WSIconicButtonItem";
	String TextField = "org.webswing.forms.toolkit.item.WSTextFieldItem";
	String TextArea = "org.webswing.forms.toolkit.item.WSTextAreaItem";
	String Checkbox = "org.webswing.forms.toolkit.item.WSCheckboxItem";
	String PopList = "org.webswing.forms.toolkit.item.WSPopListItem";
	String SpinList = "org.webswing.forms.toolkit.item.WSSpinListItem";
	String TList = "org.webswing.forms.toolkit.item.WSTListItem";
	String RadioButton = "org.webswing.forms.toolkit.item.WSRadioButtonItem";
	String ComboBox = "org.webswing.forms.toolkit.item.WSComboBoxItem";
	String Slider = "org.webswing.forms.toolkit.item.WSSliderItem";
	String Progress = "org.webswing.forms.toolkit.item.WSProgressItem";
//	String Tree = "org.webswing.forms.toolkit.item.WSTreeItem";
	
	// special
	String ToggleButton = "ToggleButton"; // WSCheckboxItem with custom VToggle implementation class, see WSCheckboxItem.onCreate
	
}
