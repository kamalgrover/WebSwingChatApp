package org.webswing.toolkit.api.migration.forms;

import java.awt.Component;

public interface WSFormsComponent<T extends WSItem> {

	public String getItemId();
	
	public Component getComponent();
	
	public T getComponentItem();
	
}
