package org.webswing.toolkit.api.component;

import java.awt.Point;

/**
 * Result of overriding of location of auto-undocked window.
 */
public class UndockLocation {

	private Point location;

	public Point getLocation() {
		return location;
	}

	public void setLocation(Point location) {
		this.location = location;
	}
	
}
