package org.webswing.toolkit.api.component;

public interface HtmlPanelBuilder {

	/**
	 * Build the HtmlPanel instance.
	 * @return instance of HtmlPanel
	 */
	public HtmlPanel build();
	
	/**
	 * Build an HtmlPanel JavaFX node. The returned node can be cast to javafx.scene.layout.Pane.
	 * To include the HtmlPanel node inside a JFXPanel, use forJFXPanel method of builder.
	 * @return instance of HtmlPanel node
	 */
	public HtmlPanelNode buildNode();
	
	/**
	 * Specify a name of a custom web component that should be automatically created as a content of html panel in frontend.
	 * You need to manually register the web component in your custom index.html.
	 * It is not mandatory to specify a web component, you can create the contents of html panel manually using windowsListener in your custom index.html.
	 * @param webComponent name of a web component to use as an implementation of the html panel content
	 * @return this builder
	 */
	public HtmlPanelBuilder webComponent(String webComponent);
	
	/**
	 * Specify a JFXPanel instance which is going to contain the HtmlPanel node. Use this for building an HtmlPanel node for JavaFX using buildNode() method.
	 * @param jfxPanel the JFXPanel to contain the built HtmlPanel node
	 * @return this builder
	 */
	public HtmlPanelBuilder forJFXPanel(Object jfxPanel);
	
}
