package org.webswing.toolkit.api.component;

import java.awt.Point;

import org.webswing.toolkit.api.browser.WindowUserScreenInfo;

/**
 * Undock event used when overriding location of auto-undocked window. Provides information about user screen where the window is going to be opened.
 * Last known screen position is non-null only in case that the window has been previously rendered in browser and did not close in Swing after browser window has been closed.
 */
public class UndockEvent {
	
	private WindowUserScreenInfo userScreenInfo;
	private Point lastKnownScreenPosition;
	
	public UndockEvent() {
	}

	public WindowUserScreenInfo getUserScreenInfo() {
		return userScreenInfo;
	}

	public void setUserScreenInfo(WindowUserScreenInfo userScreenInfo) {
		this.userScreenInfo = userScreenInfo;
	}

	public Point getLastKnownScreenPosition() {
		return lastKnownScreenPosition;
	}

	public void setLastKnownScreenPosition(Point lastKnownScreenPosition) {
		this.lastKnownScreenPosition = lastKnownScreenPosition;
	}
	
}
