package org.webswing.toolkit.api.component;

import org.webswing.toolkit.api.action.WebActionCallListener;
import org.webswing.toolkit.api.action.WebWindow;
import org.webswing.toolkit.api.action.WebWindowActionListener;

public interface HtmlPanelNode extends WebWindow {

	public abstract void addWebWindowActionListener(WebWindowActionListener listener);
	public abstract void removeWebWindowActionListener(WebWindowActionListener listener);
	public abstract void setActionCallListener(WebActionCallListener listener);
	
	public abstract String getWindowId();
	
}
