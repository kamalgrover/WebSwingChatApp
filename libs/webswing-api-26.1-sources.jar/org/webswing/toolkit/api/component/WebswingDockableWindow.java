package org.webswing.toolkit.api.component;

public interface WebswingDockableWindow {
	
	public static final String DOCK_TYPE_POPUP = "POPUP";
	public static final String DOCK_TYPE_TAB = "TAB";

	public boolean isAutoUndock();
	
	/**
	 * Override browser window position before the browser window opens.
	 * This is called only if isAutoUndock() is true and only once before the window is first rendered in browser.
	 * Return null to skip override and use window's current location.
	 * Note that off-screen positions will be corrected by browser to show the whole window content.
	 * Please do not block this method, it is called during rendering cycle.
	 * @param event <br>
	 * 		UndockEvent.userScreenInfo: information about screen on client's side where the window is going to be opened <br>
	 * 		UndockEvent.lastKnownScreenPosition: last known screen position of the browser window where the window has been rendered,
	 * 		not null only in case the browser window has been closed by user but the window did not hide and is about to be reopened on client's side
	 * @return desired browser window position on user's screen or null to skip override
	 */
	public default UndockLocation overrideAutoUndockedLocation(UndockEvent event) {
		return null;
	}
	
	/**
	 * Override default dock type set in configuration. Two dock types are supported - WebswingDockableWindow.DOCK_TYPE_POPUP and 
	 * WebswingDockableWindow.DOCK_TYPE_TAB. Determined whether the undocked window should open in a popup or a new tab.
	 * @return null to take the value from configuration or the preferred dock type
	 */
	public default String getDockType() {
		return null;
	}
	
}
