package org.webswing.toolkit.api.browser;

public enum UserScreenOrientation {

	landscape_primary("landscape-primary"),
	landscape_secondary("landscape-secondary"),
	portrait_primary("portrait-primary"),
	portrait_secondary("portrait-secondary");

	private String value;
	
	private UserScreenOrientation(String value) {
		this.value = value;
	}
	
	public static UserScreenOrientation fromString(String value) {
		for (UserScreenOrientation uso : values()) {
			if (uso.value.equals(value)) {
				return uso;
			}
		}
		return landscape_primary;
	}
	
}
