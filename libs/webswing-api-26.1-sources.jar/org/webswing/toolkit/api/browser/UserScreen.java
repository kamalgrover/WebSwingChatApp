package org.webswing.toolkit.api.browser;

/**
 * For details on properties see <a href="https://w3c.github.io/window-placement/">https://w3c.github.io/window-placement/</a>.
 */
public class UserScreen {

	private String label;
	private int availLeft;
	private int availTop;
	private int availWidth;
	private int availHeight;
	private int angle;
	private boolean primary;
	private UserScreenOrientation orientation;

	public UserScreen(String label, int availLeft, int availTop, int availWidth, int availHeight, int angle, boolean primary, UserScreenOrientation orientation) {
		super();
		this.label = label;
		this.availLeft = availLeft;
		this.availTop = availTop;
		this.availWidth = availWidth;
		this.availHeight = availHeight;
		this.angle = angle;
		this.primary = primary;
		this.orientation = orientation;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + angle;
		result = prime * result + availHeight;
		result = prime * result + availLeft;
		result = prime * result + availTop;
		result = prime * result + availWidth;
		result = prime * result + ((label == null) ? 0 : label.hashCode());
		result = prime * result + ((orientation == null) ? 0 : orientation.hashCode());
		result = prime * result + (primary ? 1231 : 1237);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserScreen other = (UserScreen) obj;
		if (angle != other.angle)
			return false;
		if (availHeight != other.availHeight)
			return false;
		if (availLeft != other.availLeft)
			return false;
		if (availTop != other.availTop)
			return false;
		if (availWidth != other.availWidth)
			return false;
		if (label == null) {
			if (other.label != null)
				return false;
		} else if (!label.equals(other.label))
			return false;
		if (orientation != other.orientation)
			return false;
		if (primary != other.primary)
			return false;
		return true;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public int getAvailLeft() {
		return availLeft;
	}

	public void setAvailLeft(int availLeft) {
		this.availLeft = availLeft;
	}

	public int getAvailTop() {
		return availTop;
	}

	public void setAvailTop(int availTop) {
		this.availTop = availTop;
	}

	public int getAvailWidth() {
		return availWidth;
	}

	public void setAvailWidth(int availWidth) {
		this.availWidth = availWidth;
	}

	public int getAvailHeight() {
		return availHeight;
	}

	public void setAvailHeight(int availHeight) {
		this.availHeight = availHeight;
	}

	public int getAngle() {
		return angle;
	}

	public void setAngle(int angle) {
		this.angle = angle;
	}

	public boolean isPrimary() {
		return primary;
	}

	public void setPrimary(boolean primary) {
		this.primary = primary;
	}

	public UserScreenOrientation getOrientation() {
		return orientation;
	}

	public void setOrientation(UserScreenOrientation orientation) {
		this.orientation = orientation;
	}

}
