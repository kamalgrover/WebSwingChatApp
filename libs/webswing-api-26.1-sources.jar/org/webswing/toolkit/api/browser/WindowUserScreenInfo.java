package org.webswing.toolkit.api.browser;

import java.awt.Dimension;
import java.awt.Point;

public class WindowUserScreenInfo {

	/**
	 * Outer location of browser window
	 */
	private Point browserWindowLocation;

	/**
	 * Outer dimension of browser window
	 */
	private Dimension browserWindowSize;

	/**
	 * User screen info
	 */
	private UserScreen userScreen;

	public WindowUserScreenInfo(Point browserWindowLocation, Dimension browserWindowSize, UserScreen userScreen) {
		super();
		this.browserWindowLocation = browserWindowLocation;
		this.browserWindowSize = browserWindowSize;
		this.userScreen = userScreen;
	}

	public Point getBrowserWindowLocation() {
		return browserWindowLocation;
	}

	public Dimension getBrowserWindowSize() {
		return browserWindowSize;
	}

	public UserScreen getUserScreen() {
		return userScreen;
	}

}
