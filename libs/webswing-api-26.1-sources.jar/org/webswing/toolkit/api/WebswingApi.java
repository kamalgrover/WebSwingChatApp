package org.webswing.toolkit.api;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Window;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import javax.swing.JComponent;
import javax.swing.JFileChooser;

import org.webswing.toolkit.api.action.ConsentListener;
import org.webswing.toolkit.api.action.WebActionCallListener;
import org.webswing.toolkit.api.action.WebActionListener;
import org.webswing.toolkit.api.action.WebActionResponse;
import org.webswing.toolkit.api.action.WebWindow;
import org.webswing.toolkit.api.audio.MediaRecorder;
import org.webswing.toolkit.api.browser.UserScreen;
import org.webswing.toolkit.api.browser.WindowUserScreenInfo;
import org.webswing.toolkit.api.clipboard.BrowserTransferable;
import org.webswing.toolkit.api.clipboard.PasteRequestContext;
import org.webswing.toolkit.api.clipboard.WebswingClipboardData;
import org.webswing.toolkit.api.component.HtmlPanel;
import org.webswing.toolkit.api.component.HtmlPanelBuilder;
import org.webswing.toolkit.api.exception.AppSettingException;
import org.webswing.toolkit.api.file.WebswingFileChooserProvider;
import org.webswing.toolkit.api.lifecycle.AppStateListener;
import org.webswing.toolkit.api.lifecycle.WebswingShutdownListener;
import org.webswing.toolkit.api.lifecycle.WebswingStartupPhase;
import org.webswing.toolkit.api.linkedview.LinkedViewListener;
import org.webswing.toolkit.api.security.UserWindowsDisconnectedListener;
import org.webswing.toolkit.api.security.WebswingExtendedUser;
import org.webswing.toolkit.api.security.WebswingUser;
import org.webswing.toolkit.api.security.WebswingUserEventHandler;
import org.webswing.toolkit.api.security.WebswingUserListener;
import org.webswing.toolkit.api.url.WebswingUrlState;
import org.webswing.toolkit.api.url.WebswingUrlStateChangeListener;

/**
 * Webswing API used by Swing application for easy integration.
 */
public interface WebswingApi {

	/**
	 * To get the clipboard data received from browser after CTRL+V key events.
	 * Browser security allows access to clipboard only in these events.
	 * Typically used for customized clipboard integration, while the built-in integration is disabled in configuration ("allowLocalClipboard" is false).
	 * You can use the following steps:
	 * 1. Create a new context menu item called "Paste from browser".
	 * 2. When the user clicks on the context menu item, open a modal dialog asking the user to press CTRL+V.
	 * 3. Listen for the CTRL+V keystroke in the modal dialog.
	 * 4. When the user presses CTRL+V, call the following method to get the clipboard content.
	 * 5. Once you have the clipboard content, you can display it in the modal dialog or use it however you need.
	 *
	 * @return Latest clipboard content received from browser
	 * @group Clipboard Services
	 * @exampleMethodName getBrowserClipboardExample1
	 */
	public BrowserTransferable getBrowserClipboard();

	/**
	 * Request the user to paste from browser clipboard by showing a built-in html modal dialog.
	 * This method will block EDT thread (by showing an invisible modal JDialog) until response received from user.
	 * Typically used for customized clipboard integration, while the built-in integration is disabled in configuration ("allowLocalClipboard" is false).
	 *
	 * @param ctx request context
	 * @return User submited clipboard content received from browser (null if cancelled)
	 * @group Clipboard Services
	 * @exampleMethodName getBrowserClipboardExample2
	 */
	public BrowserTransferable getBrowserClipboard(PasteRequestContext ctx);

	/**
	 * Sends the specified data to browser.
	 * A toolbar will appear in browser displaying the data.
	 * User can click or press CTRL+C to store the content to local clipboard.
	 * Typically used for customized clipboard integration, while the built-in integration is disabled in configuration ("allowLocalClipboard" is false).
	 *
	 * @param content clipboard data to be sent to browser
	 * @group Clipboard Services
	 * @exampleMethodName sendClipboardExample1
	 */
	public void sendClipboard(WebswingClipboardData content);

	/**
	 * Sends the current Swing clipboard content to browser.
	 * A toolbar will appear in browser displaying the data.
	 * User can click or press CTRL+C to store the content to local clipboard.
	 * Typically used for customized clipboard integration, while the built-in integration is disabled in configuration ("allowLocalClipboard" is false).
	 *
	 * @group Clipboard Services
	 * @exampleMethodName sendClipboardExample2
	 */
	public void sendClipboard();

	/**
	 * Adds a WebswingBrowserActionListener to listen to javascript browser initiated events.
	 *
	 * @param listener The listener to add
	 * @group Event Listener Services
	 */
	public void addBrowserActionListener(WebActionListener listener);

	/**
	 * Removed a WebswingBrowserActionListener.
	 *
	 * @param listener The listener to remove
	 * @group Event Listener Services
	 */
	public void removeBrowserActionListener(WebActionListener listener);

	/**
	 * Set a WebActionCallListener to listen to javascript browser initiated calls, using webswingInstance0.callAction.
	 * 
	 * @param actionCallListener The listener to set
	 * @group Event Listener Services
	 */
	public void setActionCallListener(WebActionCallListener actionCallListener);
	
	/**
	 * Invoke the given runnable when Webswing is launched and user context is already available.
	 * When starting an IDLE instance with app main class configured in pre-launch, the runnable will be invoked when user is connecting to the IDLE instance.
	 * When starting a normal instance with app main class configured in standard launch, the runnable will be invoked immediately.
	 * The runnable is not guaranteed to be executed on EDT thread or on caller thread.
	 * @param runnable runnable to invoke
	 * @group Event Listener Services
	 */
	public void invokeWhenLaunched(Runnable runnable);
	
	/**
	 * Get the current phase of Webswing startup. After main.Main call the phase is 'started'.
	 * After pre-launch main execution the phase is 'prelaunched'.
	 * After launch main execution the phase is 'launched'.
	 * 
	 * @return current phase of Webswing startup
	 * @group Event Listener Services
	 */
	public WebswingStartupPhase getWebswingStartupPhase();
	
	/**
	 * Add listener that is triggered when Webswing requests swing application to exit.
	 * If there is no explicit shutdown listener Webswing use default shutdown procedure (send window closing event to all windows).
	 * Otherwise listeners are fired.
	 * It is expected the result of listener execution will exit the swing process.
	 * Otherwise the swing process will be forcefully terminated after defined timeout
	 * (system property "webswing.waitForExit", default: 30000)
	 *
	 * @param listener listener to add
	 * @group Event Listener Services
	 */
	public void addShutdownListener(WebswingShutdownListener listener);

	/**
	 * Remove shutdown listener
	 *
	 * @param listener listener to remove
	 * @group Event Listener Services
	 */
	public void removeShutdownListener(WebswingShutdownListener listener);

	/**
	 * When swing application exit and shutdown process takes longer time to process, invoking this method will notify user (web session) the application has finished, and disconnect the user from the session.
	 * Swing Application process is removed from running sessions list even though the process might still be running.
	 *
	 * @param forceKillTimeout how long (in Ms) to wait for process to finish. After this time the process is forcefully terminated.
	 * @group Event Listener Services
	 */
	public void notifyShutdown(int forceKillTimeout);

	/**
	 * Register a URL state change listener
	 *
	 * @param listener the listener
	 * @group Event Listener Services
	 */
	public void addUrlStateChangeListener(WebswingUrlStateChangeListener listener);

	/**
	 * Remove URL state change listener
	 *
	 * @param listener the listener
	 * @group Event Listener Services
	 */

	public void removeUrlStateChangeListener(WebswingUrlStateChangeListener listener);

	/**
	 * URL State
	 *
	 * @return current user's URL state (parsed hash fragment of URL) or null if no user is connected.
	 * @group Event Listener Services
	 */
	public WebswingUrlState getUrlState();

	/**
	 * See {@link WebswingApi#setUrlState(WebswingUrlState, boolean)}.
	 * This method will not trigger url change event in {@link WebswingUrlStateChangeListener}
	 *
	 * @param state state object url is generated from
	 * @group Event Listener Services
	 * @exampleMethodName setUrlStateExample1
	 */
	public void setUrlState(WebswingUrlState state);

	/**
	 * Sets the hash Fragment of users browser URL to represent the current state of the swing application.
	 * Intended for use in combination with {@link WebswingUrlStateChangeListener} and/or {@link WebswingApi#getUrlState()}
	 *
	 * @param state           state object url is generated from
	 * @param fireChangeEvent if true, invoking this method will trigger url change event
	 * @group Event Listener Services
	 * @exampleMethodName setUrlStateExample2
	 */
	public void setUrlState(WebswingUrlState state, boolean fireChangeEvent);

	/**
	 * Add listener to receive notifications when user (primary/mirror view) connects or disconnects from session
	 *
	 * @param listener listener to add
	 * @group Event Listener Services
	 */
	public void addUserConnectionListener(WebswingUserListener listener);

	/**
	 * Remove user listener
	 *
	 * @param listener listener to remove
	 * @group Event Listener Services
	 */
	public void removeUserConnectionListener(WebswingUserListener listener);

	/**
	 * Set listener to listen to event when primary user disconnects and there are windows being rendered.
	 * @param listener listener to set
	 * @group Event Listener Services
	 */
	public void setUserWindowsDisconnectedListener(UserWindowsDisconnectedListener listener);
	
	/**
	 * Add listener to receive notifications about Linked View.
	 *
	 * @param listener listener to add
	 * @group Event Listener Services
	 */
	public void addLinkedViewListener(LinkedViewListener listener);

	/**
	 * Remove Linked View listener.
	 *
	 * @param listener listener to remove
	 * @group Event Listener Services
	 */
	public void removeLinkedViewListener(LinkedViewListener listener);
	
	/**
	 * Invoke the given handler when primary user connection from browser to the app is established.
	 * If a primary user is already connected at the time of calling this method, the handler will be invoked immediately.
	 * If multiple primary users are connected, the handler will invoke for each of them.
	 * The handler is not guaranteed to be executed on EDT thread or on caller thread.
	 * @param handler handler to invoke
	 * @param oneTime should the handler be invoked only on a single occurrence or should it be invoked every time a user is connected
	 * @group Event Listener Services
	 */
	public void invokeWhenPrimaryUserConnected(WebswingUserEventHandler handler, boolean oneTime);
	
	/**
	 * Invoke the given handler when primary user connection from browser to the app is lost.
	 * If there is already a disconnected user at the time of calling this method, the handler will be invoked immediately.
	 * Only last disconnected user is returned.
	 * The handler is not guaranteed to be executed on EDT thread or on caller thread.
	 * @param handler handler to invoke
	 * @param oneTime should the handler be invoked only on a single occurrence or should it be invoked every time a user is disconnected
	 * @group Event Listener Services
	 */
	public void invokeWhenPrimaryUserDisconnected(WebswingUserEventHandler handler, boolean oneTime);
	
	/**
	 * Sends an action event with optional data to the browser.
	 *
	 * @param actionName name of action to be sent
	 * @param data       string encoded data
	 * @param binaryData binary data
	 * @group Event Listener Services
	 * @exampleMethodName sendActionEventExample1
	 */
	public void sendActionEvent(String actionName, String data, byte[] binaryData);

	/**
	 * Sends an action event to a WebWindow, with optional data to the browser.
	 *
	 * @param webWindow  window to receive the action event
	 * @param actionName name of action to be sent
	 * @param data       string encoded data
	 * @param binaryData binary data
	 * @group Event Listener Services
	 * @exampleMethodName sendActionEventExample2
	 */
	public void sendActionEvent(WebWindow webWindow, String actionName, String data, byte[] binaryData);

	/**
	 * Call an action defined in javascript webswing options API. The result of the action will be returned as a result of the returned Future.
	 * If the result of the action is a Promise, the Future will complete once the Promise is resolved. The result of the javascript action can
	 * return either string or binary data.
	 *
	 * @param actionName the name of the action to be called in javascript
	 * @param data       string encoded data
	 * @param binaryData binary data
	 * @return CompletableFuture to handle the async result
	 * @group Event Listener Services
	 * @exampleMethodName callActionExample1
	 */
	public CompletableFuture<WebActionResponse> callAction(String actionName, String data, byte[] binaryData);
	
	/**
	 * Call an action defined for a WebWindow in javascript's window 'handleActionCall' property. The result of the action will be returned as a result of the returned Future.
	 * If the result of the action is a Promise, the Future will complete once the Promise is resolved. The result of the javascript action can
	 * return either string or binary data.
	 *
	 * @param webWindow  window to receive the action call
	 * @param actionName the name of the action to be called in javascript
	 * @param data       string encoded data
	 * @param binaryData binary data
	 * @return CompletableFuture to handle the async result
	 * @group Event Listener Services
	 * @exampleMethodName callActionExample2
	 */
	public CompletableFuture<WebActionResponse> callAction(WebWindow webWindow, String actionName, String data, byte[] binaryData);

	/**
	 * Set consent listener for controlling the recording and mirroring consent flow.
	 *
	 * @param consentListener the listener instance
	 * @group Event Listener Services
	 */
	public void setConsentListener(ConsentListener consentListener);

	/**
	 * Get the outer dimensions of browser window on user's screen where the window is being rendered.
	 * Returns null if window parameter is not provided, if the window is not being rendered or if Webswing has not yet been initialized on client side.
	 * Multi screen support must be enabled for this method to return correct information.
	 *
	 * @param window get user screen dimension of browser window where this window is rendered
	 * @return outer dimension of browser window
	 * @group User Related Services
	 */
	public Dimension getDimensionOnUserScreen(Window window);

	/**
	 * Returns the position of browser window on user's screen where the window is being rendered.
	 * Returns null if window parameter is not provided, if the window is not being rendered or if Webswing has not yet been initialized on client side.
	 *
	 * @param window get location of browser window on user's screen for this window
	 * @return location of the browser window
	 * @group User Related Services
	 */
	public Point getLocationOnUserScreen(Window window);

	/**
	 * Sets the position of browser window on user's screen where the window is being rendered.
	 * This only changes the location of browser window and not the real location of Swing window.
	 * This only works for undocked windows.
	 *
	 * @param window   window to set the browser window position for
	 * @param location location on user's screen where the window should move to
	 * @group User Related Services
	 */
	public void setLocationOnUserScreen(Window window, Point location);

	/**
	 * Return the user of connected mirror view web session.
	 * Mirroring App is located in - Admin console - Session - Current App - Mirror view.
	 * Note: if admin disconnects/closes browser, this method will return null.
	 *
	 * @return user or null if mirror view session is disconnected.
	 * @group User Related Services
	 */
	public WebswingUser getMirrorViewUser();

	/**
	 * Return the user of connected web session.
	 * Note: if user disconnects/closes browser, this method will return null.
	 *
	 * @return user or null if session is disconnected.
	 * @group User Related Services
	 */
	public WebswingUser getPrimaryUser();
	
	/**
	 * Return a list of users of this connected web session.
	 * Note: if user (all users) disconnect/close browser, this method will return empty list.
	 *
	 * @return user list or empty list if session is disconnected.
	 * @group User Related Services
	 */
	public List<WebswingExtendedUser> getPrimaryUsers();

	/**
	 * Returns the IP address of the user of connected web session.
	 *
	 * @return IP address
	 * @group User Related Services
	 */
	public String getPrimaryUserIPAddress();

	/**
	 * Check if connected web session user has role defined.
	 * If no user is connected null is returned.
	 *
	 * @param role name of role
	 * @return True if user has the role, false if not. Null if no user is connected
	 * @throws WebswingApiException if communication with server fails.
	 * @group User Related Services
	 */
	public Boolean primaryUserHasRole(String role) throws WebswingApiException;

	/**
	 * Check if connected web session user has permission defined.
	 * If no user is connected null is returned.
	 *
	 * @param permission name of permission
	 * @return True if user has the permission, false if not. Null if no user is connected
	 * @throws WebswingApiException if communication with server fails.
	 * @group User Related Services
	 */
	public Boolean primaryUserIsPermitted(String permission) throws WebswingApiException;

	/**
	 * Get the information about user's screens.
	 * In case user has multiple screens, returns information about all screens, if supported by browser.
	 * This may return empty list if Webswing has not yet been initialized on client side.
	 * UserScreen values are based on data provided by browser according to <a href="https://w3c.github.io/window-placement/">W3C specification</a>.
	 * Multi screen support must be enabled for this method to return correct information.
	 *
	 * @return list of information about user's screens or empty list if Webswing is not initialized
	 * @group User Related Services
	 * @exampleMethodName getUserScreenInfoExample1
	 */
	public List<UserScreen> getUserScreenInfo();

	/**
	 * Get the information about browser window on user's screens where the particular Swing Window is rendered.
	 * This may return null if Webswing has not yet been initialized on client side.
	 * Multi screen support must be enabled for this method to return correct information.
	 *
	 * @param window get the user screen information where this window is rendered
	 * @return information about browser window on user's screens or null if Webswing is not initialized
	 * @group User Related Services
	 * @exampleMethodName getUserScreenInfoExample2
	 */
	public WindowUserScreenInfo getUserScreenInfo(Window window);

	/**
	 * Get the client's screen size.
	 * In case user has multiple screens, returns size of screen where the window is currently being rendered.
	 * When window parameter is not provided, the default user screen size is returned.
	 * This may return null if Webswing has not yet been initialized on client side.
	 * Multi screen support must be enabled for this method to return correct information.
	 *
	 * @param window get the user screen size where this window is rendered
	 * @return dimension of user screen where the window is rendered or default user screen dimension if window is not provided or null if Webswing is not initialized
	 * @group User Related Services
	 */
	public Dimension getUserScreenSize(Window window);

	/**
	 * Creates an HtmlPanel Swing component.
	 *
	 * @return instance of HtmlPanel component
	 * @group Utility Services
	 */
	public HtmlPanel createHtmlPanel();
	
	/**
	 * Creates a new HtmlPanelBuilder that helps creating HtmlPanel component.
	 *
	 * @return instance of HtmlPanelBuilder
	 * @group Utility Services
	 */
	public HtmlPanelBuilder createHtmlPanelBuilder();

	/**
	 * Returns the current average end-to-end paint latency or null if latency value is not available.
	 *
	 * @return current latency
	 * @group Utility Services
	 */
	public Integer getLatency();

	/**
	 * Get Webswing Version
	 *
	 * @return the Webswing version in 'git describe' format
	 * @group Utility Services
	 */
	public String getWebswingVersion();

	/**
	 * Returns true if current session is being mirrored.
	 * Mirroring App is located in - Admin console - Session - Current App - Mirror view.
	 *
	 * @return true if current session is being mirrored
	 * @group Utility Services
	 */
	public boolean isMirroring();

	/**
	 * Returns true if current session is being recorded.
	 * Recording App is located in - Admin console - Session - Current App - Menu - Record.
	 *
	 * @return true if current session is being recorded
	 * @group Utility Services
	 */
	public boolean isRecording();

	/**
	 * Is compositing window manager used?
	 *
	 * @deprecated
	 * @return true, since version 21.1 this is the default and only window manager
	 * @group Utility Services
	 */
	@Deprecated
	public boolean isCompositingWindowManager();

	/**
	 * Check if multi screen support is enabled in Webswing configuration.
	 *
	 * @return true if multi screen support is enabled in Webswing config
	 * @group Utility Services
	 */
	public boolean isMultiScreenSupportEnabled();

	/**
	 * Is touch mode active?
	 *
	 * @return true if session is running in touch mode, i.e. on a touch enabled device
	 * @group Utility Services
	 */
	public boolean isTouchMode();

	/**
	 * Register JFileChooser that should show Webswing integration toolbar if embedded in a window.
	 * Transparent mode is not available in this case.
	 * To hide Webswing integration toolbar use WebswingFileChooserUtil.setFileUIHidden(fileChooser, true).
	 *
	 * @param fileChooser instance of file chooser
	 * @param parent window that contains this fileChooser
	 * @group Utility Services
	 */
	public void registerCustomFileChooser(JFileChooser fileChooser, Window parent);

	/**
	 * Register a provider for custom file chooser that implements WebswingFileChooserProvider.
	 * Transparent mode is not available in this case.
	 * To hide Webswing integration toolbar use WebswingFileChooserUtil.setFileUIHidden(fileChooserProvider, true);.
	 *
	 * @param fileChooserProvider instance of file chooser provider implementation
	 * @param parent window that contains the fileChooserProvider relatedComponent
	 * @group Utility Services
	 */
	public void registerCustomFileChooserProvider(WebswingFileChooserProvider fileChooserProvider, Window parent);
	
	/**
	 * Register a global provider for file chooser that is always active until it is unregistered.
	 * No other file chooser can be activated while this file chooser provider is registered.
	 * Transparent mode is not available in this case.
	 * To hide Webswing integration toolbar use WebswingFileChooserUtil.setFileUIHidden(fileChooserProvider, true);.
	 *
	 *
	 * @param fileChooserProvider instance of file chooser provider implementation
	 * @group Utility Services
	 */
	public void registerGlobalFileChooserProvider(WebswingFileChooserProvider fileChooserProvider);
	
	/**
	 * Unregister a global provider for file chooser making it effectively inactive.
	 *
	 * @group Utility Services
	 */
	public void unregisterGlobalFileChooserProvider();
	
	/**
	 * Get the currently registered global file chooser provider or null if no active global file chooser provider is registered.
	 *
	 * @return currently registered global file chooser provider or null
	 * @group Utility Services
	 */
	public WebswingFileChooserProvider getRegisteredGlobalFileChooserProvider();
	
	/**
	 * Register a component as a receiver of DnD drop event from user's host system.
	 *
	 * @param component the component to be registered as drop receiver
	 * @group Utility Services
	 */
	public void registerDropComponent(JComponent component);
	
	/**
	 * Unregister a component as a receiver of DnD drop event from user's host system.
	 *
	 * @param component the component to be unregistered as drop receiver
	 * @group Utility Services
	 */
	public void unregisterDropComponent(JComponent component);

	/**
	 * Registers given web component to be directly rendered in its own canvas.
	 * Web components that are not directly rendered are rendered by copying parts of canvas into destination canvas.
	 * Note that for this to work you must first register a web container and webComponent must be its direct child.
	 *
	 * @param webComponent web component to register
	 * @group Utility Services
	 */
	public void registerWebComponentForDirectRendering(JComponent webComponent);

	/**
	 * Registers given container to be a parent web container and all of its child components will be rendered into separate canvases.
	 *
	 * @param container container to register
	 * @group Utility Services
	 */
	public void registerWebContainer(Container container);

	/**
	 * Is docking enabled for window?
	 * Docking mode in config must be enabled.
	 *
	 * @param window window to check
	 * @return true if docking in enabled for given window
	 * @group Utility Services
	 */
	public boolean isDockingEnabled(Window window);

	/**
	 * Check whether window is in undocked state.
	 *
	 * @param window window to check
	 * @return true if window is undocked
	 * @group Utility Services
	 */
	public boolean isUndocked(Window window);

	/**
	 * Toggle the dock state of a window.
	 * Window must be allowed to change the dock state according to config.
	 *
	 * @param window window to toggle dock state
	 * @throws IllegalArgumentException if isDockingEnabled(window) returns false
	 * @group Utility Services
	 * @exampleMethodName toggleWindowDockExample1
	 */
	public void toggleWindowDock(Window window);

	/**
	 * Toggle the dock state of a window.
	 * Window must be allowed to change the dock state according to config.
	 *
	 * @param window   window to toggle dock state
	 * @param undocked should the window be docked or undocked
	 * @throws IllegalArgumentException if isDockingEnabled(window) returns false
	 * @group Utility Services
	 * @exampleMethodName toggleWindowDockExample2
	 */
	public void toggleWindowDock(Window window, boolean undocked);

	/**
	 * Render Window in provided tab. This method is useful when you opened a new Linked View and you want to move a Window to that view.
	 * 
	 * @param window Window to move rendering for
	 * @param tabId id of the tab where the Window should render
	 * @param position optional position where to place the Window, keeps the current position if null
	 * @group Utility Services
	 */
	public void renderWindowInTab(Window window, String tabId, Point position);
	
	/**
	 * Returns a full connection URL to create a new Linked View. Open this URL in browser to create a new connection to this instance.
	 * You can then render Windows in the new tab using WebswingApi.renderWindowInTab.
	 * In linkedViewListener you can listen to initialization event of the Linked View.
	 * The URL can be used multiple times.
	 * Returns null if no primary user is connected to this instance.
	 * 
	 * @return linked view URL
	 * @group Utility Services
	 */
	public String getLinkedViewUrl();
	
	/**
	 * Returns a linked view URL for specific connected user. Use this method if there are multiple users from different security contexts connected to this instance.
	 * Returns null if given user is not connected to this instance.
	 * 
	 * @return linked view URL
	 * @group Utility Services
	 */
	public String getLinkedViewUrlForUser(WebswingExtendedUser user);
	
	/**
	 * Returns a linked view URL for specific Window, which is rendered in a particular user security context.
	 * Use this method if there are multiple users from different security contexts connected to this instance.
	 * Returns null if given Window is not being rendered or if a related user is not connected to this instance.
	 * 
	 * @return linked view URL
	 * @group Utility Services
	 */
	public String getLinkedViewUrlForWindow(Window window);
	
	/**
	 * Reset session timeout to prevent automatic termination.
	 * Useful if a long-running operation has to finish even if user disconnects or is inactive for longer timeframe.
	 * Note: Reset needs to be called in periods shorter than configured session timeout. ("webswing.sessionTimeoutSec" system property)
	 * Note2: This method has no effect if session timeout is set to 0
	 *
	 * @group Utility Services
	 */
	public void resetInactivityTimeout();

	/**
	 * Overrides the default inactivity timeout value from configuration for current session only. Only takes effect if 'timeoutIfInactive' configuration option is enabled.
	 *
	 * @param seconds new inactivity timeout in seconds
	 * @group Utility Services
	 */
	public void setInactivityTimeout(long seconds);

	/**
	 * Control the recording consent flow - accept/deny, if there is an active consent request for recording.
	 *
	 * @param accept should the recording consent be accepted
	 * @group Utility Services
	 */
	public void resolveRecordingConsent(boolean accept);

	/**
	 * Control the mirroring consent flow - accept/deny, if there is an active consent request for mirroring.
	 *
	 * @param accept should the mirroring consent be accepted
	 * @group Utility Services
	 */
	public void resolveMirroringConsent(boolean accept);

	/**
	 * Immediately locks this session. When locked user can not use this session and a lock overlay is displayed. To unlock user has to re-login.
	 *
	 * @group Utility Services
	 */
	public void lockSession();

	/**
	 * Check if session is locked.
	 *
	 * @return true if this session is locked.
	 * @group Utility Services
	 */
	public boolean isSessionLocked();
	
	/**
	 * Set a Webswing setting. The list of Webswing settings is available in Admin Console app configuration.
	 * 
	 * @param key Webswing setting key
	 * @param value Webswing setting value
	 * @throws AppSettingException when it is not allowed to set this setting at runtime
	 * @group Utility Services
	 */
	public void setSetting(String key, String value) throws AppSettingException;

	/**
	 * Get a Webswing setting value.
	 * 
	 * @param key Webswing setting key
	 * @return value of the Webswing setting
	 * @group Utility Services
	 */
	public String getSetting(String key);

	/**
	 * Creates a new MediaRecorder instance. Use it to start an audio or video recording.
	 *
	 * @group Utility Services
	 */
	public MediaRecorder createMediaRecorder();

	/**
	 * Add listener to receive notifications about Application State.
	 *
	 * @param listener listener to add
	 * @group Event Listener Services
	 */
	public void addAppStateListener(AppStateListener listener);

	/**
	 * Remove Application State listener.
	 *
	 * @param listener listener to remove
	 * @group Event Listener Services
	 */
	public void removeAppStateListener(AppStateListener listener);
}
