package org.webswing.toolkit.api.jslink;

public class JSException extends RuntimeException {

	private static final long serialVersionUID = 57364875636583685L;

	public JSException(String msg) {
		super(msg);
	}
	
	public JSException(Exception e) {
		super(e);
	}

}