package org.webswing.toolkit.api.jslink;

public interface JSObjectApi {

	public JSObject newJSObject();
	
}
