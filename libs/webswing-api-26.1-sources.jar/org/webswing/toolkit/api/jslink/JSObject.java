package org.webswing.toolkit.api.jslink;

import java.awt.Toolkit;

import org.webswing.toolkit.api.WebswingApiProvider;
import org.webswing.toolkit.api.WebswingUtil;

/**
 * @deprecated Deprecated in favor of JsLinkDirect.
 * @since 22.2
 */
@Deprecated
public abstract class JSObject {

	public abstract void setSlot(int index, Object value) throws JSException;

	public abstract Object getSlot(int index) throws JSException;

	public abstract void removeMember(String name) throws JSException;

	public abstract void setMember(String name, Object value) throws JSException;

	public abstract Object getMember(String name) throws JSException;

	public abstract Object eval(String s) throws JSException;

	public abstract Object call(String methodName, Object[] args) throws JSException;
    
    public static JSObject getWindow(Object param) throws JSException {
    	return getWindow();
    }
    
    public static JSObject getWindow() throws JSException {
    	JSObjectApi api = getJSObjectApi();
    	if (api == null) {
    		return null;
    	}
    	return api.newJSObject();
    }
    
    private static JSObjectApi getJSObjectApi() {
		if (WebswingUtil.isWebswing()) {
			return ((WebswingApiProvider) Toolkit.getDefaultToolkit()).getJSObjectApi();
		} else {
			return null;
		}
	}

}
