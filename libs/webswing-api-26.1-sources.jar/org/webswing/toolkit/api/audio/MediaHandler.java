package org.webswing.toolkit.api.audio;

public interface MediaHandler extends MediaRecorder {

	/**
	 * Pushes a chunk of encoded media data to the registered listener.
	 *
	 * @param eventData non-null encoded media bytes
	 */
	void notifyMediaStream(byte[] eventData);

	/**
	 * Notifies the listener that recording has successfully started.
	 */
	void notifyMediaStart();

	/**
	 * Notifies the listener that recording has completely stopped and no more data will be emitted.
	 *
	 * @param eventData encoded media bytes
	 */
	void notifyMediaStop(byte[] eventData);

	/**
	 * Notifies the listener that a non-recoverable error occurred during recording.
	 *
	 * @param error error description
	 */
	void notifyMediaError(String error);
	
}
