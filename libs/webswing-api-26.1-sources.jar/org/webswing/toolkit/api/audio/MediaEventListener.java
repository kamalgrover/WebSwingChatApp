package org.webswing.toolkit.api.audio;

public interface MediaEventListener {

	/**
	 * Called when a media session successfully starts or resumes.
	 */
	void onStart();

	/**
	 * Called when a media session stops normally.
	 */
	void onStop();

	/**
	 * Called when an unrecoverable error occurs during a media session.
	 *
	 * @param error description of the failure
	 */
	void onError(String error);

	/**
	 * Called when a chunk of media stream data is available.
	 *
	 * @param streamData the next contiguous block of stream bytes
	 */
	void onReceived(byte[] streamData);
}