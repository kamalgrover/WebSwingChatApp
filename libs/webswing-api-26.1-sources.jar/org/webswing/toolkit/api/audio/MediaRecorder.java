package org.webswing.toolkit.api.audio;

public interface MediaRecorder {

	/**
	 * Returns a unique, stable identifier for this recorder instance.
	 *
	 * @return non-null unique identifier for the recorder
	 */
	String getId();

	/**
	 * Starts recording media.
	 *
	 * @param audio          whether to capture the audio track
	 * @param video          whether to capture the video track
	 * @param codecs         codec hint
	 * @param streamInterval interval in milliseconds for pushing chunked stream data
	 */
	void startRecording(boolean audio, boolean video, String codecs, Integer streamInterval);

	/**
	 * Stops an active recording and releases any underlying resources.
	 */
	void stopRecording();

	/**
	 * Registers (or replaces) the listener that will receive media events from this recorder.
	 *
	 * @param listener the listener to receive callbacks
	 */
	void setMediaListener(MediaEventListener listener);
	
	/**
	 * Dispose this media recorder.
	 */
	void dispose();
	
}