package org.webswing.toolkit.api.security;

public class UserEvent {
	
	private WebswingExtendedUser user;
	private String ipAddress;

	public UserEvent(WebswingExtendedUser user) {
		super();
		this.user = user;
	}
	
	public UserEvent(WebswingExtendedUser user, String ipAddress) {
		this(user);
		this.ipAddress = ipAddress;
	}

	public WebswingUser getUser() {
		return user;
	}
	
	public WebswingExtendedUser getExtendedUser() {
		return user;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public String getTabId() {
		return user.getTabId();
	}

	public String getSecuritySuffix() {
		return user.getSecuritySuffix();
	}

	public boolean isSecurityContextPerTab() {
		return user.isSecurityContextPerTab();
	}
	
	public String getCustomArgs() {
		return user.getCustomArgs();
	}

	public UserEvent copy() {
		return new UserEvent(user, ipAddress);
	}

}
