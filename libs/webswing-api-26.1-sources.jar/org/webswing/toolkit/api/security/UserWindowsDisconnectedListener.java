package org.webswing.toolkit.api.security;

import java.awt.Window;
import java.util.List;

public interface UserWindowsDisconnectedListener {

	/**
	 * The method provides a disconnected user event and a list of Windows that are still rendering in the disconnected user's context.
	 * Return a list of Windows that should keep rendering. If you don't want to render the Windows anymore, close/dispose the Windows
	 * and return an empty/reduced list.
	 * Windows not returned and still showing will be blocked from Webswing rendering. To unblock a window hide it and show it again.
	 * 
	 * @param evt user disconnected event
	 * @param disconnectedWindows Windows that are being rendered in disconnected user's security context
	 * @return a list of disconnected Windows that should keep rendering
	 */
	default List<Window> onPrimaryUserWindowsDisconnected(UserEvent evt, List<Window> disconnectedWindows) {
		return disconnectedWindows;
	}
	
}
