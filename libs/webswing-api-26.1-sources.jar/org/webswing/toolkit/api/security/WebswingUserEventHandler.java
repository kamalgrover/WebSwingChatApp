package org.webswing.toolkit.api.security;

@FunctionalInterface
public interface WebswingUserEventHandler {

	public void handleUserEvent(UserEvent evt);
	
}
