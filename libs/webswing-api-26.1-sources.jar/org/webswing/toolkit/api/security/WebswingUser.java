package org.webswing.toolkit.api.security;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * Representation of user logged-in to Webswing through web interface. 
 */
public interface WebswingUser {

	public static final String OS_MAC = "Mac";
	public static final String OS_WINDOWS = "Windows";
	public static final String OS_LINUX = "Linux";
	public static final String OS_ANDROID = "Android";
	public static final String OS_IPHONE = "IPhone";
	public static final String OS_UNKNOWN = "Unknown";
	
	/**
	 * @return Unique user id
	 */
	String getUserId();

	/**
	 * @return map of user attributes specific to configured security module implementation. 
	 */
	Map<String, Serializable> getUserAttributes();
	
	/**
	 * @return list user roles
	 */
	List<String> getUserRoles();

}
