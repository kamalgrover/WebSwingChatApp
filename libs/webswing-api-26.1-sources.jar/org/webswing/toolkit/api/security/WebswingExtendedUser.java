package org.webswing.toolkit.api.security;

import java.awt.Window;
import java.util.List;

/**
 * Representation of user logged-in to Webswing through web interface, with extra info. 
 */
public interface WebswingExtendedUser extends WebswingUser {

	/**
	 * @return IP address of the user
	 */
	String getIPAddress();
	
	/**
	 * @return tabId of the original user connection, the tab might not be connected after user closes the original browser tab
	 */
	String getTabId();
	
	/**
	 * @return security suffix of the user's security session (when securityContextPerTab is enabled)
	 */
	String getSecuritySuffix();
	
	/**
	 * @return true if user's security session has securityContextPerTab enabled
	 */
	boolean isSecurityContextPerTab();
	
	/**
	 * @return custom user arguments from browser
	 */
	String getCustomArgs();
	
	/**
	 * Check if this user has given role assigned.
	 * @param role role to check
	 */
	boolean hasRole(String role);
	
	/**
	 * Check if this user has given permission assigned.
	 * @param permission permission to check
	 */
	boolean isPermitted(String permission);
	
	/**
	 * @return a list of Windows being rendered in this user's context
	 */
	List<Window> getRenderedWindows();
	
	/**
	 * @return a list of tabIds of currently connected browser tabs (windows) in this user's context
	 */
	List<String> getConnectedTabs();
	
	/**
	 * @return client OS of the user (based on User-Agent), values from WebswingUser.OS_* value
	 */
	String getClientOS();
	
}
