package org.webswing.toolkit.api.security;

public interface WebswingUserListener {

	default void onPrimaryUserConnected(UserEvent evt){};

	default void onPrimaryUserDisconnected(UserEvent evt){};

	default void onMirrorViewConnected(UserEvent evt){};

	default void onMirrorViewDisconnected(UserEvent evt){};
	
}
