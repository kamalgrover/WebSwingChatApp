package org.webswing.toolkit.api.file;
/**
 * Webswing by default supports javax.swing.FileNameExtensionFilter in its filechooser integration.
 * This interface allows making custom file chooser filters compatible with Webswing file upload/download integration.
 */
public interface WebswingFileNameExtensionFilter {
	/**
	 * Returns the set of file name extensions files are tested against. Use extensions without dot (ie. ["pdf","doc"])
	 *
	 * @return the set of file name extensions files are tested against
	 */
	String[] getExtensions();
}
