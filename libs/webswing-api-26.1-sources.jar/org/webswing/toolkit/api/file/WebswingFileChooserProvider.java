package org.webswing.toolkit.api.file;

import java.io.File;

import javax.swing.JComponent;
import javax.swing.filechooser.FileFilter;

/**
 * Interface that provides API for handling file operations with Webswing.
 * Implement this interface and register it through WebswingAPI to be able to handle file/upload download without need to have a JFileChooser instance.
 */
public interface WebswingFileChooserProvider {

	/**
	 * Get currently selected file filter.
	 * @return file filter
	 */
	default FileFilter getFileFilter() {
		return null;
	}

	/**
	 * Get an array of choosable file filters.
	 * @return file filters
	 */
	default FileFilter[] getChoosableFileFilters() {
		return new FileFilter[0];
	}

	/**
	 * Set current file filter.
	 * @param ff file filter
	 */
	default void setFileFilter(FileFilter ff) {}
	
	/**
	 * Get stored client property.
	 * @param key client property key
	 * @return client property value
	 */
	default Object getClientProperty(String key) {
		JComponent relC = getRelatedComponent();
		if (relC != null) {
			return relC.getClientProperty(key);
		}
		return null;
	}
	
	/**
	 * Store client property.
	 * @param key client property key
	 * @param value client property value
	 */
	default void putClientProperty(String key, Object value) {
		JComponent relC = getRelatedComponent();
		if (relC != null) {
			relC.putClientProperty(key, value);
		}
	}
	
	/**
	 * Name that identifies this file chooser in javascript frontend. It is not mandatory to use a name.
	 * @return name of this file chooser, name of the relatedComponent by default
	 */
	default String getName() {
		JComponent relC = getRelatedComponent();
		if (relC != null) {
			return relC.getName();
		}
		return null;
	}
	
	/**
	 * Get a component that is responsible for this file chooser provider. This can be a component that implements 
	 * the custom file chooser or a parent component or any other empty component that is visible.
	 * Webswing uses this component to determine when the file chooser integration is active.
	 * The integration is active only if the component is part of a component tree of a Window that is currently active and the component itself is showing.
	 * Do not change this component after registering the file chooser provider with Webswing.
	 * <br><br>
	 * If you want the file chooser to be active until it is unregistered again, return null component and register the file chooser with WebswingApi.registerGlobalFileChooserProvider.
	 * In such case you must also override and implement getClientProperty() and putClientProperty() methods of this interface.
	 * 
	 * @return component
	 */
	JComponent getRelatedComponent();
	
	/**
	 * Get the current directory of this file chooser.
	 * @return file representing the current directory
	 */
	File getCurrentDirectory();

	/**
	 * Set the current directory of this file chooser.
	 * @param directory file representing the directory to be set as current
	 */
	void setCurrentDirectory(File directory);
	
	/**
	 * Request file chooser to rescan (refresh) its current directory.
	 */
	void rescanCurrentDirectory();
	
	/**
	 * Mark given files as selected in the file chooser.
	 * @param files files to be set as selected
	 */
	void setSelectedFiles(File[] files);
	
	/**
	 * Mark given file as selected in the file chooser.
	 * @param f file to be set as selected
	 */
	void setSelectedFile(File f);
	
	/**
	 * Get files that are marked as selected.
	 * @return selected files
	 */
	File[] getSelectedFiles();
	
	/**
	 * Get file that is marked as selected.
	 * @return selected file
	 */
	File getSelectedFile();
	
	/**
	 * Does this file chooser support multiselection?
	 * @return true is multiselection is enabled
	 */
	boolean isMultiSelectionEnabled();

}
