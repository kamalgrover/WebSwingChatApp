package org.webswing.toolkit.api.file;

import javax.swing.JFileChooser;

public class WebswingFileChooserUtil {

	public static final String ALLOW_DOWNLOAD_OVERRIDE = "webswing.allowDownload";
	public static final String ALLOW_UPLOAD_OVERRIDE = "webswing.allowUpload";
	public static final String ALLOW_DELETE_OVERRIDE = "webswing.allowDelete";
	public static final String CUSTOM_FILE_CHOOSER = "webswing.customFileChooser";
	public static final String FILE_CHOOSER_REFERENCE = "webswing.fileChooserReference";
	public static final String FILE_UI_HIDDEN = "webswing.fileUIHidden";
	public static final String FORCE_TRANSPARENT_FILE_CHOOSER = "webswing.forceTransparentFileChooser";

	public static void setDownloadAllowed(JFileChooser chooser, Boolean canDownload) {
		chooser.putClientProperty(ALLOW_DOWNLOAD_OVERRIDE, canDownload);
	}

	public static void setUploadAllowed(JFileChooser chooser, Boolean canUpload) {
		chooser.putClientProperty(ALLOW_UPLOAD_OVERRIDE, canUpload);
	}

	public static void setDeleteAllowed(JFileChooser chooser, Boolean canDelete) {
		chooser.putClientProperty(ALLOW_DELETE_OVERRIDE, canDelete);
	}

	public static void overridePermissions(JFileChooser chooser, Boolean canDownload, Boolean canUpload, Boolean canDelete) {
		setDownloadAllowed(chooser, canDownload);
		setUploadAllowed(chooser, canUpload);
		setDeleteAllowed(chooser, canDelete);
	}

	public static void resetPermissions(JFileChooser chooser) {
		setDownloadAllowed(chooser, null);
		setUploadAllowed(chooser, null);
		setDeleteAllowed(chooser, null);
	}
	
	public static void setFileUIHidden(JFileChooser chooser, boolean hidden) {
		chooser.putClientProperty(FILE_UI_HIDDEN, hidden ? true : null);
	}
	
	public static void setForceTransparentFileChooser(JFileChooser chooser, boolean force) {
		chooser.putClientProperty(FORCE_TRANSPARENT_FILE_CHOOSER, force ? true : null);
	}
	
	// --- WebswingFileChooserProvider
	
	public static void setDownloadAllowed(WebswingFileChooserProvider provider, Boolean canDownload) {
		provider.putClientProperty(ALLOW_DOWNLOAD_OVERRIDE, canDownload);
	}
	
	public static void setUploadAllowed(WebswingFileChooserProvider provider, Boolean canUpload) {
		provider.putClientProperty(ALLOW_UPLOAD_OVERRIDE, canUpload);
	}
	
	public static void setDeleteAllowed(WebswingFileChooserProvider provider, Boolean canDelete) {
		provider.putClientProperty(ALLOW_DELETE_OVERRIDE, canDelete);
	}
	
	public static void overridePermissions(WebswingFileChooserProvider provider, Boolean canDownload, Boolean canUpload, Boolean canDelete) {
		setDownloadAllowed(provider, canDownload);
		setUploadAllowed(provider, canUpload);
		setDeleteAllowed(provider, canDelete);
	}
	
	public static void resetPermissions(WebswingFileChooserProvider provider) {
		setDownloadAllowed(provider, null);
		setUploadAllowed(provider, null);
		setDeleteAllowed(provider, null);
	}
	
	public static void setFileUIHidden(WebswingFileChooserProvider provider, boolean hidden) {
		provider.putClientProperty(FILE_UI_HIDDEN, hidden ? true : null);
	}
	
	public static void setForceTransparentFileChooser(WebswingFileChooserProvider provider, boolean force) {
		provider.putClientProperty(FORCE_TRANSPARENT_FILE_CHOOSER, force ? true : null);
	}
	
}
