package org.webswing.toolkit.api.input;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.swing.InputMap;
import javax.swing.KeyStroke;
import javax.swing.UIDefaults;
import javax.swing.UIManager;
import javax.swing.plaf.InputMapUIResource;
import javax.swing.text.DefaultEditorKit;

import org.webswing.toolkit.api.security.WebswingUser;

/**
 * Helper class to patch InputMaps used by Swing's Look and Feel.
 */
public class InputMapPatcher {

	private static final Map<String, String[]> defaultMacPatchActions = new HashMap<>();
	
	static {
		// KeyBindings using META key from com.apple.laf.AquaKeyBindings
		defaultMacPatchActions.put(DefaultEditorKit.selectAllAction, new String[] { "meta A" });
		defaultMacPatchActions.put("selectAll", new String[] { "meta A" });
		defaultMacPatchActions.put(DefaultEditorKit.copyAction, new String[] { "meta C" });
		defaultMacPatchActions.put("copy", new String[] { "meta C" });
		defaultMacPatchActions.put(DefaultEditorKit.pasteAction, new String[] { "meta V" });
		defaultMacPatchActions.put("paste", new String[] { "meta V" });
		defaultMacPatchActions.put(DefaultEditorKit.cutAction, new String[] { "meta X" });
		defaultMacPatchActions.put("cut", new String[] { "meta X" });
		defaultMacPatchActions.put("unselect", new String[] { "meta BACK_SLASH" });
		defaultMacPatchActions.put(DefaultEditorKit.beginLineAction, new String[] { "meta LEFT", "meta KP_LEFT" });
		defaultMacPatchActions.put(DefaultEditorKit.selectionBeginLineAction, new String[] { "shift meta LEFT", "shift meta KP_LEFT" });
		defaultMacPatchActions.put(DefaultEditorKit.selectionEndLineAction, new String[] { "shift meta RIGHT", "shift meta KP_RIGHT" });
		defaultMacPatchActions.put("selection-page-right", new String[] { "meta shift PAGE_DOWN" });
		defaultMacPatchActions.put("selection-page-left", new String[] { "meta shift PAGE_UP" });
		defaultMacPatchActions.put(DefaultEditorKit.endAction, new String[] { "meta DOWN", "meta KP_DOWN" });
		defaultMacPatchActions.put(DefaultEditorKit.beginAction, new String[] { "meta UP", "meta KP_UP" });
		defaultMacPatchActions.put(DefaultEditorKit.selectionEndAction, new String[] { "shift meta DOWN", "shift meta KP_DOWN" });
		defaultMacPatchActions.put(DefaultEditorKit.selectionBeginAction, new String[] { "shift meta UP", "shift meta KP_UP" });
		defaultMacPatchActions.put("activate-link-action", new String[] { "meta SPACE" });
		defaultMacPatchActions.put("next-link-action", new String[] { "meta T" });
		defaultMacPatchActions.put("previous-link-action", new String[] { "meta shift T" });
	}
	
	private InputMapPatcher() {}
	
	/**
	 * Patch default input maps of current Look and Feel with correct platform specific values defined in InputMapPatcher.getDefaultMacPatchActions().
	 * 
	 * Use this method to support pressing META+C for copy action for end-users on Mac platform while server is running on a different platform
	 * or running with LaF not supporting Mac input map.
	 * 
	 * Call this method early in app's main method call, after setting Look and Feel and before creating components.
	 * If some UI components are already created, patch input maps and then call SwingUtilities.updateComponentTreeUI on each top-level window.
	 */
	public static void patchMac() {
		patchMac(defaultMacPatchActions);
	}
	
	/**
	 * Patch default input maps of current Look and Feel with correct platform specific values defined in provided map.
	 * 
	 * Use this method to support pressing META+C for copy action for end-users on Mac platform while server is running on a different platform
	 * or running with LaF not supporting Mac input map.
	 * 
	 * Call this method early in app's main method call, after setting Look and Feel and before creating components.
	 * If some UI components are already created, patch input maps and then call SwingUtilities.updateComponentTreeUI on each top-level window.
	 */
	public static void patchMac(Map<String, String[]> macPatchActions) {
		UIDefaults d = UIManager.getLookAndFeelDefaults();
        List<Object> keys = new ArrayList<>(d.keySet());

        for (Object k : keys) {
            Object v = d.get(k);
            InputMap original = toInputMap(v, d);
            if (original == null) {
            	continue;
            }

            InputMapUIResource patched = new InputMapUIResource();

            KeyStroke[] all = original.allKeys();
            if (all == null) {
            	continue;
            }

            Set<String> patchKeys = new HashSet<>();
            for (KeyStroke ks : all) {
                Object action = original.get(ks);
                
                if (macPatchActions.containsKey(action)) {
                	// mark that it needs to be patched
                	patchKeys.add((String) action);
                } else {
                	// keep as-is
                	patched.put(ks, action);
                }
            }
            
            for (String patchKey : patchKeys) {
            	String[] bindings = macPatchActions.get(patchKey);
            	for (String binding : bindings) {
            		patched.put(KeyStroke.getKeyStroke(binding), patchKey);
            	}
            }

            // Store back; using an InputMap directly is fine
            d.put(k, patched);
        }
    }
	
	/**
	 * Returns platform string of the platform where this JVM is running.
	 * 
	 * @return one of the WebswingUser.OS_* values
	 */
	public static String getServerPlatform() {
		String os = System.getProperty("os.name").toLowerCase();
		if (os.contains("win")) {
			return WebswingUser.OS_WINDOWS;
		}

		if (os.contains("mac")) {
			return WebswingUser.OS_MAC;
		}

		if (os.contains("linux")) {
			return WebswingUser.OS_LINUX;
		}

		return WebswingUser.OS_UNKNOWN;
	}
	
	/**
	 * Returns a map of <action_name> : [<key_binding_1>, <key_binding_2>].
	 * 
	 * Where <action_name> is a String, e.g. DefaultEditorKit.copyAction, or 'activate-link-action',
	 * and <key_binding> is a String that can be interpreted by KeyStroke.getKeyStroke(<key_binding>), e.g. "meta C" or "meta SPACE".
	 * 
	 * You can remove, change or add mappings and then use the map in patchMac(macPatchActions) method.
	 * 
	 * @return default mac patch actions map
	 */
	public static Map<String, String[]> getDefaultMacPatchActions() {
		return new HashMap<>(defaultMacPatchActions);
	}
	
	private static InputMap toInputMap(Object v, UIDefaults d) {
		if (v instanceof InputMap) {
			return (InputMap) v;
		}
		if (v instanceof UIDefaults.LazyInputMap) {
			// materialize the lazy map
			Object made = ((UIDefaults.LazyInputMap) v).createValue(d);
			return (made instanceof InputMap) ? (InputMap) made : null;
		}
		return null;
	}
	
}
