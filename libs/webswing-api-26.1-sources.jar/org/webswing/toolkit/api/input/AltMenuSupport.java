package org.webswing.toolkit.api.input;

import java.awt.KeyboardFocusManager;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.Action;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.MenuSelectionManager;

/**
 * In Windows environment when user presses ALT key the window menu is focused. If the menu is already open ALT key closes the menu and removed focus.
 * This util provides same functionality for pressing ALT key when application runs in Linux environment.
 */
public class AltMenuSupport {
	
	private boolean altDown;
	private boolean altUsedAsModifier;
	private boolean menuCanceledByAlt;
	
	/**
	 * Install the ALT key support for given JFrame.
	 * @param frame frame to install support on
	 */
	public void install(JFrame frame) {
		KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventDispatcher(e -> {
			JMenuBar menuBar = frame.getJMenuBar();
			if (menuBar == null) {
				return false;
			}

			MenuSelectionManager msm = MenuSelectionManager.defaultManager();
			int keyCode = e.getKeyCode();

			// Any non-Alt key pressed while Alt is down means Alt is being
			// used as a modifier (e.g. Alt+D), so do not focus menu on Alt release.
			if (altDown && keyCode != KeyEvent.VK_ALT && e.getID() == KeyEvent.KEY_PRESSED) {
				altUsedAsModifier = true;
				return false; // let accelerators/menu shortcuts work normally
			}

			if (keyCode != KeyEvent.VK_ALT) {
				return false;
			}

			if (e.getID() == KeyEvent.KEY_PRESSED) {
				if (!altDown) {
					altDown = true;
					altUsedAsModifier = false;
					menuCanceledByAlt = false;

					// If menu is already open, Alt closes it (Windows-like)
					if (msm.getSelectedPath().length > 0) {
						msm.clearSelectedPath();
						menuCanceledByAlt = true;
						e.consume();
						return true;
					}
				}
				return false;
			}

			if (e.getID() == KeyEvent.KEY_RELEASED) {
				try {
					// Only bare Alt should focus the menu
					if (altDown && !altUsedAsModifier && !menuCanceledByAlt && msm.getSelectedPath().length == 0) {
						Action takeFocus = menuBar.getActionMap().get("takeFocus");
						if (takeFocus != null) {
							takeFocus.actionPerformed(new ActionEvent(menuBar, ActionEvent.ACTION_PERFORMED, "takeFocus"));
							e.consume();
							return true;
						}
					}
					return false;
				} finally {
					altDown = false;
					altUsedAsModifier = false;
					menuCanceledByAlt = false;
				}
			}

			return false;
		});
	}
}