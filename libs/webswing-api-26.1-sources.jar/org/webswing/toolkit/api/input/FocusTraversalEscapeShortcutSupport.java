package org.webswing.toolkit.api.input;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.HashSet;
import java.util.Set;

/**
 * Use this utility class to install custom focus escape traversal keys for all (or some) JTable and JTextArea components.
 * The original CTRL+TAB and CTRL+SHIFT+TAB traversal keys to escape focus tap of JTable and JTextArea don't work with Webswing running in browser,
 * because these shortcuts are reserved for browser. The shortcuts CTRL+SHIFT+LEFT and CTRL+SHIFT+RIGHT are used instead if accessibility is enabled in browser.
 * To disable the default Webswing escape focus traversal shortcuts use Advanced Setting 'webswing.disableAccessibilityFocusEscapeRemap'.
 */
public final class FocusTraversalEscapeShortcutSupport {

	private static final String INSTALLED_KEY = "webswing.customFocusTraversal.installed";

	private static final KeyStroke FORWARD = KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, InputEvent.CTRL_DOWN_MASK | InputEvent.SHIFT_DOWN_MASK);
	private static final KeyStroke BACKWARD = KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, InputEvent.CTRL_DOWN_MASK | InputEvent.SHIFT_DOWN_MASK);

	/**
	 * Install globally (for all JTable and JTextArea components) the default shortcuts CTRL+SHIFT+LEFT (backward) and CTRL+SHIFT+RIGHT (forward).
	 * The shortcuts are installed once the component receives focus.
	 */
	public static void installGlobally() {
		installGlobally(FORWARD, BACKWARD);
	}
	
	/**
	 * Install globally (for all JTable and JTextArea components) custom shortcuts for backward and forward focus traversal.
	 * The shortcuts are installed once the component receives focus.
	 */
	public static void installGlobally(KeyStroke forwardTraversalKeyStroke, KeyStroke backwardTraversalKeyStroke) {
		KeyboardFocusManager.getCurrentKeyboardFocusManager().addPropertyChangeListener("permanentFocusOwner", evt -> {
			Object value = evt.getNewValue();
			if (!(value instanceof JComponent)) {
				return;
			}
			
			JComponent c = (JComponent) value;

			if (c instanceof JTable || c instanceof JTextArea) {
				installOn(c, forwardTraversalKeyStroke, backwardTraversalKeyStroke);
			}
		});
	}

	/**
	 * Install the default shortcuts CTRL+SHIFT+LEFT (backward) and CTRL+SHIFT+RIGHT (forward) only for given component.
	 */
	public static void installOn(JComponent c) {
		installOn(c, FORWARD, BACKWARD);
	}
	
	/**
	 * Install custom shortcuts for backward and forward focus traversal only for given component.
	 */
	public static void installOn(JComponent c, KeyStroke forwardTraversalKeyStroke, KeyStroke backwardTraversalKeyStroke) {
		if (Boolean.TRUE.equals(c.getClientProperty(INSTALLED_KEY))) {
			return;
		}
		c.putClientProperty(INSTALLED_KEY, Boolean.TRUE);

		Set<AWTKeyStroke> forwardKeys = new HashSet<>(c.getFocusTraversalKeys(KeyboardFocusManager.FORWARD_TRAVERSAL_KEYS));
		if (!forwardKeys.contains(forwardTraversalKeyStroke)) {
			forwardKeys.add(forwardTraversalKeyStroke);
			c.setFocusTraversalKeys(KeyboardFocusManager.FORWARD_TRAVERSAL_KEYS, forwardKeys);
		}
		
		Set<AWTKeyStroke> backwardKeys = new HashSet<>(c.getFocusTraversalKeys(KeyboardFocusManager.BACKWARD_TRAVERSAL_KEYS));
		if (!backwardKeys.contains(backwardTraversalKeyStroke)) {
			backwardKeys.add(backwardTraversalKeyStroke);
			c.setFocusTraversalKeys(KeyboardFocusManager.BACKWARD_TRAVERSAL_KEYS, backwardKeys);
		}
	}
	
}