package org.webswing.toolkit.api.linkedview;

public class LinkedViewEvent {

	private String linkedViewName;
	private String tabId;
	private String userId;

	public LinkedViewEvent(String linkedViewName, String tabId, String userId) {
		super();
		this.linkedViewName = linkedViewName;
		this.tabId = tabId;
		this.userId = userId;
	}

	public String getLinkedViewName() {
		return linkedViewName;
	}

	public void setLinkedViewName(String linkedViewName) {
		this.linkedViewName = linkedViewName;
	}

	public String getTabId() {
		return tabId;
	}

	public void setTabId(String tabId) {
		this.tabId = tabId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}
