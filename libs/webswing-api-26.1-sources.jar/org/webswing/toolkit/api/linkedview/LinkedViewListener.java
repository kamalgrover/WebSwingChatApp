package org.webswing.toolkit.api.linkedview;

public interface LinkedViewListener {

	default void onLinkedViewInitialized(LinkedViewEvent evt) {};
	
}
