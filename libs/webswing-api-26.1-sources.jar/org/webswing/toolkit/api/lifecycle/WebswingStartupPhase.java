package org.webswing.toolkit.api.lifecycle;

public enum WebswingStartupPhase {

	started,
	prelaunched,
	launched;
	
}
