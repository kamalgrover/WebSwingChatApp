package org.webswing.toolkit.api.lifecycle;

public class AppStateEvent {

	private String tabId;
	
	public AppStateEvent() {
	}

	public AppStateEvent(String tabId) {
		this.tabId = tabId;
	}

	public String getTabId() {
		return tabId;
	}

	public void setTabId(String tabId) {
		this.tabId = tabId;
	}
	
}
