package org.webswing.toolkit.api.lifecycle;

import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class WebswingPrelaunch {
	
	private static final Logger logger = Logger.getLogger(WebswingPrelaunch.class.getName());

	private Runnable invokeWhenPrelaunchDone;
	private boolean prelaunchDone;
		
	public WebswingPrelaunch() {
	}
	
	public abstract void prelaunch(String[] args);
	
	protected synchronized void prelaunchDone() {
		prelaunchDone = true;
		if (invokeWhenPrelaunchDone != null) {
			invokePrelaunchRunnable(invokeWhenPrelaunchDone);
			invokeWhenPrelaunchDone = null;
		}
	}
	
	/**
	 * Do not call this method directly.
	 * @param r Runnable to run after the prelaunch task is done
	 */
	public synchronized void invokeWhenPrelaunchDone(Runnable r) {
		if (prelaunchDone) {
			invokePrelaunchRunnable(r);
		} else {
			invokeWhenPrelaunchDone = r;
		}
	}
	
	private void invokePrelaunchRunnable(Runnable r) {
		new Thread(() -> {
			try {
				r.run();
			} catch (Throwable t) {
				logger.log(Level.SEVERE, "Failed to invoke when prelaunch done!", t);
			}
		}, "Webswing-PreLaunch-Done").start();
	}
	
}
