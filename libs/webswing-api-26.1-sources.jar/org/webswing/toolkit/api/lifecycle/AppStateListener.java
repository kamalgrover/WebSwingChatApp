package org.webswing.toolkit.api.lifecycle;

public interface AppStateListener {

	default void onLock() {
	}

	default void onUnlock() {
	}

	default void onFreezeTab(AppStateEvent event) {
	}

	default void onResumeTab(AppStateEvent event) {
	}
}
