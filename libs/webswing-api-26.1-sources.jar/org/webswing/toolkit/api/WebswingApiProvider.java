package org.webswing.toolkit.api;

import org.webswing.toolkit.api.jslink.JSObjectApi;
import org.webswing.toolkit.api.migration.WebswingMigrationApi;

/**
 * Implemented by Webswing's WebToolkit  
 */
public interface WebswingApiProvider {
	
	WebswingApi getApi();
	
	JSObjectApi getJSObjectApi();
	
	WebswingMigrationApi getWebswingMigrationApi();
	
	WebswingMigrationApi getExtendedWebswingMigrationApi();
	
}
