package org.webswing.toolkit.api.car;

import javax.swing.JComponent;

public interface WebUIStateProvider {

	WebUIState extractState(JComponent c);
	
}
