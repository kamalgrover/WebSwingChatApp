package org.webswing.toolkit.api.car;

import java.awt.Component;
import java.awt.DefaultFocusTraversalPolicy;

/**
 * Use this FTP for migrated components that are fully migrated and they handle focus of their child components in web. 
 */
public class WebComponentFocusTraversalPolicy extends DefaultFocusTraversalPolicy {

	private static final long serialVersionUID = -5116983457661913895L;
	
	public WebComponentFocusTraversalPolicy() {
		super();
	}
	
	@Override
	protected boolean accept(Component aComponent) {
		return false;
	}

}
