package org.webswing.toolkit.api.car.forms;

import java.awt.Component;

import org.webswing.toolkit.api.action.WebActionEvent;

public interface FormsWebUIEventHandler {

	void handleWebEvent(Component c, WebActionEvent event);
	
}
