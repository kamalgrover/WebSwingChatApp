package org.webswing.toolkit.api.car.forms;

import java.awt.Component;

import org.webswing.toolkit.api.car.WebUIState;

public interface FormsWebUIStateProvider {

	WebUIState extractState(Component c);
	
}
