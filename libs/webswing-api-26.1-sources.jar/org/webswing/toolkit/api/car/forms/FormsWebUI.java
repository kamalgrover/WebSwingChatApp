package org.webswing.toolkit.api.car.forms;

public interface FormsWebUI extends FormsWebUIStateProvider, FormsWebUIEventHandler {

}