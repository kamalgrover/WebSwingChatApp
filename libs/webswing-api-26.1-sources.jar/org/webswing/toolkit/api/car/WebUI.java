package org.webswing.toolkit.api.car;

import java.awt.Graphics;
import java.awt.Toolkit;

import javax.swing.JComponent;

import org.webswing.toolkit.api.WebswingApiProvider;

public interface WebUI extends WebUIStateProvider, WebUIEventHandler {

	default boolean paintWeb(Graphics g, JComponent c) {
		return ((WebswingApiProvider) Toolkit.getDefaultToolkit()).getWebswingMigrationApi().paintWeb(g, c);
	}
	
}