package org.webswing.toolkit.api.car;

import java.awt.image.VolatileImage;

public interface VolatileImageProvider {

	VolatileImage getImage();
	
}
