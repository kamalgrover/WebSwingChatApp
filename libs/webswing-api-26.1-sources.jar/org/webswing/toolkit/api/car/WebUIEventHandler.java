package org.webswing.toolkit.api.car;

import javax.swing.JComponent;

import org.webswing.toolkit.api.action.WebActionEvent;

public interface WebUIEventHandler {

	void handleWebEvent(JComponent c, WebActionEvent event);
	
}
