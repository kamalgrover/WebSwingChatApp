package org.webswing.toolkit.api.car;

import java.util.HashMap;
import java.util.Map;

public class WebUIState {
    
	private String element;
	private String webComponent;
    private Map<String, String> props = new HashMap<>();

    public String getElement() {
        return element;
    }

	public void setElement(String element) {
        this.element = element;
    }

    public String getWebComponent() {
		return webComponent;
	}

	public void setWebComponent(String webComponent) {
		this.webComponent = webComponent;
	}

	public Map<String, String> getProps() {
    	if (this.props == null) {
    		this.props = new HashMap<>();
    	}
        return props;
    }

    public void setProps(Map<String, String> props) {
        this.props = props;
    }
    
    public void addProp(String name, String value) {
    	if (this.props == null) {
    		this.props = new HashMap<>();
    	}
    	if (value == null) {
    		this.props.remove(name);
    	} else {
    		this.props.put(name, value);
    	}
    }
    
    public void removeProp(String name) {
    	if (this.props != null) {
    		this.props.remove(name);
    	}
    }
    
    public static class Builder {
    	
    	private WebUIState webUIState = new WebUIState();
    	
    	public Builder(String webComponent) {
    		webUIState.setWebComponent(webComponent);
		}
    	
    	public static Builder forWebComponent(String webComponent) {
    		return new Builder(webComponent);
    	}
    	
    	public Builder withElement(String element) {
    		webUIState.setElement(element);
    		return this;
    	}
    	
    	public Builder withProperties(Map<String, String> props) {
    		webUIState.getProps().clear();
    		if (props != null) {
    			webUIState.getProps().putAll(props);
    		}
    		return this;
    	}
    	
    	public Builder addProperty(String name, String value) {
    		webUIState.addProp(name, value);
    		return this;
    	}
    	
    	public WebUIState build() {
    		return webUIState;
    	}
    	
    }

}
