package org.webswing.toolkit.api.car;

import java.awt.Component;

public interface WebUIGraphics {
	
    void paintWebComponent(Component c, WebUIState extractState);

}
