package org.webswing.toolkit.api;

import java.awt.Toolkit;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import org.webswing.toolkit.api.migration.WebswingMigrationApi;

/**
 * Helper class to get API instance
 */
public class WebswingUtil {
	
	public static final String __OBFUSCATE = "OBF:";
	private static final List<String> COMMANDS = Arrays.asList("obfuscate", "hash");

	/**
	 * @return true if this instance is running inside Webswing app container
	 */
	public static boolean isWebswing() {
		Toolkit t = Toolkit.getDefaultToolkit();
		return t instanceof WebswingApiProvider;
	}

	/**
	 * Api Swing application can utilize to integrate with Webswing's lifecycle and security.
	 * @return Webswing API instance or null if not running in Webswing app container.
	 */
	public static WebswingApi getWebswingApi() {
		if (isWebswing()) {
			return ((WebswingApiProvider) Toolkit.getDefaultToolkit()).getApi();
		} else {
			return null;
		}
	}

	/**
	 * Migration API to migrate JComponents to HTML Web Components.
	 * @return Migration API or null if not running in Webswing app container
	 */
	public static WebswingMigrationApi getWebswingMigrationApi() {
		if (isWebswing()) {
			return ((WebswingApiProvider) Toolkit.getDefaultToolkit()).getWebswingMigrationApi();
		} else {
			return null;
		}
	}
	
	public static String obfuscate(String s)
    {
        StringBuilder buf = new StringBuilder();
        byte[] b = s.getBytes(StandardCharsets.UTF_8);

        buf.append(__OBFUSCATE);
        for (int i = 0; i < b.length; i++)
        {
            byte b1 = b[i];
            byte b2 = b[b.length - (i + 1)];
            if (b1 < 0 || b2 < 0)
            {
                int i0 = (0xff & b1) * 256 + (0xff & b2);
                String x = Integer.toString(i0, 36).toLowerCase(Locale.ENGLISH);
                buf.append("U0000", 0, 5 - x.length());
                buf.append(x);
            }
            else
            {
                int i1 = 127 + b1 + b2;
                int i2 = 127 + b1 - b2;
                int i0 = i1 * 256 + i2;
                String x = Integer.toString(i0, 36).toLowerCase(Locale.ENGLISH);

                int j0 = Integer.parseInt(x, 36);
                int j1 = (i0 / 256);
                int j2 = (i0 % 256);
                byte bx = (byte)((j1 + j2 - 254) / 2);

                buf.append("000", 0, 4 - x.length());
                buf.append(x);
            }
        }
        return buf.toString();
    }
	
	public static void main(String[] args) throws IOException
    {
        if (!isValidInput(args)) {
            printUsageAndExit();
        }
        
        String command = args[0];
        String password = args[1];

        switch (command) {
            case "obfuscate":
                System.out.println(obfuscate(password));
                break;
            case "hash":
                System.out.println(HashUtil.hash(password.toCharArray()));
                break;
            default:
                printUsageAndExit(); // This should never be reached
        }
    }
	
	private static boolean isValidInput(String[] args) {
        return args.length > 1 && COMMANDS.contains(args[0]);
    }

    private static void printUsageAndExit() {
        System.out.println("Usage:\n" +
                "java -jar webswing-api.jar obfuscate <password>\n" +
                "java -jar webswing-api.jar hash <password>");
        System.exit(1);
    }
}
