package org.webswing.toolkit.api.text;

import javax.swing.text.JTextComponent;

public class WebswingTextComponentUtil {

	public static final String INPUT_MODE = "webswing.inputMode";
	
	/**
	 * See <a href="https://developer.mozilla.org/en-US/docs/Web/HTML/Global_attributes/inputmode">https://developer.mozilla.org/en-US/docs/Web/HTML/Global_attributes/inputmode</a>.
	 */
	public static enum InputMode {
		none,
		text,
		decimal,
		numeric,
		tel,
		search,
		email,
		url
	}

	/**
	 * Set HTML inputMode for given text component. Select from one of the predefined supported input modes. If inputMode parameter is null, the input mode will be cleared.
	 */
	public static void setInputMode(JTextComponent textComponent, InputMode inputMode) {
		if (inputMode == null) {
			textComponent.putClientProperty(INPUT_MODE, null);
			return;
		}
		textComponent.putClientProperty(INPUT_MODE, inputMode.name());
	}
	
}