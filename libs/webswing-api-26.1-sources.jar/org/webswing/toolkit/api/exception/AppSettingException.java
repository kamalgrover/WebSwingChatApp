package org.webswing.toolkit.api.exception;

public class AppSettingException extends Exception {

	private static final long serialVersionUID = -6196717332329564305L;

	public AppSettingException(String message) {
		super(message);
	}
	
}
