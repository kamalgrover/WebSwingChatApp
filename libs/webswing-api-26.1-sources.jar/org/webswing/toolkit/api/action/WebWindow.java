package org.webswing.toolkit.api.action;

import java.util.concurrent.CompletableFuture;

import org.webswing.toolkit.api.WebswingUtil;

public interface WebWindow {

	public default void performWebAction(String actionName, String data, byte[] binaryData) {
		WebswingUtil.getWebswingApi().sendActionEvent(this, actionName, data, binaryData);
	}
	
	public default CompletableFuture<WebActionResponse> callAction(String actionName, String data, byte[] binaryData) {
		return WebswingUtil.getWebswingApi().callAction(this, actionName, data, binaryData);
	}
	
	public void handleWebActionEvent(WebActionEvent webActionEvent);
	
	public default WebActionResponse handleWebActionCall(WebActionEvent webActionEvent) {
		throw new UnsupportedOperationException("Not implemented.");
	}
	
	public void handleWindowInitialized();
}
