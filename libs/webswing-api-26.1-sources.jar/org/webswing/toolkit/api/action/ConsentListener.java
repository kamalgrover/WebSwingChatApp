package org.webswing.toolkit.api.action;

public interface ConsentListener {

	/**
	 * Return false to prevent the default recording consent dialog to be shown.
	 * This method is called only if recording consent dialog is enabled for this application.
	 * You can change the default consent dialog messages with event.setConsentMessages()
	 * <ul>
	 * 	<li>webswing.recording.title = Session recording</li>
	 * 	<li>webswing.recording.message = Administrator wants to record your session.\nDo you want to allow the recording?</li>
	 * 	<li>webswing.recording.allow = Allow</li>
	 * 	<li>webswing.recording.deny = Deny</li>
	 * </ul>
	 * You can open a custom consent dialog in this method. Call WebswingApi.recordingConsentAccept() and WebswingApi.recordingConsentDeny() to control the consent flow.
	 * Please do not block this method by opening a JOptionPane, instead open it inside SwingUtilities.invokeLater.
	 * @param event consent event
	 * @return false to prevent the default recording consent dialog to be shown
	 */
	public boolean beforeRecordingConsentDialogShowed(ConsentEvent event);
	
	/**
	 * Return false to prevent the default mirroring consent dialog to be shown.
	 * This method is called only if mirroring consent dialog is enabled for this application.
	 * You can change the default consent dialog messages with event.setConsentMessages()
	 * <ul>
	 * 	<li>webswing.mirroring.title = Session mirroring</li>
	 * 	<li>webswing.mirroring.message = Administrator wants to mirror and take control of your session.\nDo you want to allow the mirroring?</li>
	 * 	<li>webswing.mirroring.allow = Allow</li>
	 * 	<li>webswing.mirroring.deny = Deny</li>
	 * </ul>
	 * You can open a custom consent dialog in this method. Call WebswingApi.mirroringConsentAccept() and WebswingApi.mirroringConsentDeny() to control the consent flow.
	 * Please do not block this method by opening a JOptionPane, instead open it inside SwingUtilities.invokeLater.
	 * @param event consent event
	 * @return false to prevent the default mirroring consent dialog to be shown
	 */
	public boolean beforeMirroringConsentDialogShowed(ConsentEvent event);
	
	public void recordingStarted();
	
	public void recordingFinished();
	
	public void mirroringStarted();
	
	public void mirroringFinished();
	
}