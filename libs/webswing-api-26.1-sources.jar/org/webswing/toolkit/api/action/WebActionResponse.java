package org.webswing.toolkit.api.action;

public class WebActionResponse {

	private String data;
	private byte[] binaryData;
	
	public WebActionResponse(String data, byte[] binaryData) {
		this.data = data;
		this.binaryData = binaryData;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public byte[] getBinaryData() {
		return binaryData;
	}

	public void setBinaryData(byte[] binaryData) {
		this.binaryData = binaryData;
	}
	
}
