package org.webswing.toolkit.api.action;

public interface WebActionCallListener {

	public WebActionResponse actionCalled(WebActionEvent actionEvent);
	
}
