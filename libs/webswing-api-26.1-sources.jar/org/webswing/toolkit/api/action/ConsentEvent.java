package org.webswing.toolkit.api.action;

import java.util.Properties;

public class ConsentEvent {

	public static enum ConsentType {
		recording, mirror
	}

	private ConsentType consentType;
	private Properties consentMessages;

	public ConsentEvent(ConsentType consentType) {
		super();
		this.consentType = consentType;
	}

	public ConsentType getConsentType() {
		return consentType;
	}

	public void setConsentMessages(Properties consentMessages) {
		this.consentMessages = consentMessages;
	}

	public Properties getConsentMessages() {
		return consentMessages;
	}

}
